-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 04, 2018 at 03:48 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `elaravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_07_17_201705_create_tbl_admin_table', 1),
(2, '2018_07_17_220413_create_tbl_category_table', 2),
(3, '2018_07_18_212935_create_tbl_manufacture_table', 3),
(4, '2018_07_19_144051_create_tbl_products_table', 4),
(5, '2018_07_19_183022_create_tbl_products_table', 5),
(6, '2018_07_20_143652_create_tbl_slider_table', 6),
(7, '2018_07_21_192819_create_tbl_customer_table', 7),
(8, '2018_07_22_111443_create_tbl_shipping_table', 8),
(9, '2018_07_22_183857_create_tbl_payment_table', 9),
(10, '2018_07_22_184003_create_tbl_order_table', 9),
(11, '2018_07_22_184100_create_tbl_order_details_table', 9),
(12, '2018_07_25_184954_create_tbl_payment_table', 10),
(13, '2018_07_25_185022_create_tbl_order_table', 10),
(14, '2018_07_25_185053_create_tbl_order_details_table', 10);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(10) UNSIGNED NOT NULL,
  `admin_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_email`, `admin_password`, `admin_name`, `admin_phone`, `created_at`, `updated_at`) VALUES
(1, 'arnab@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'arnab', '01859443458', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `category_id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publication_status` int(2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`category_id`, `category_name`, `category_description`, `publication_status`, `created_at`, `updated_at`) VALUES
(4, 'Women', 'This is women Collection', 1, NULL, NULL),
(5, 'Child', 'This is electronics', 1, NULL, NULL),
(6, 'Electronics', 'This is electronics', 1, NULL, NULL),
(7, 'Other', 'This is other', 1, NULL, NULL),
(8, 'Furniture', 'This is furniture', 0, NULL, NULL),
(9, 'Sports', 'This is Sports', 1, NULL, NULL),
(10, 'Laptop', 'This is Laptop', 1, NULL, NULL),
(11, 'Cloths', 'This is cloths', 1, NULL, NULL),
(12, 'Books', 'This is books area', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `customer_id` int(10) UNSIGNED NOT NULL,
  `customer_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`customer_id`, `customer_name`, `customer_email`, `customer_password`, `customer_mobile`, `created_at`, `updated_at`) VALUES
(1, 'Rabiul Hasan', 'xhasan.me@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '01859443458', NULL, NULL),
(4, 'Rabiul Hasan', 'kuddus@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '01859443459', NULL, NULL),
(5, 'Rabiul Hasan', 'xhasan.me@gmail.com', '8d70d8ab2768f232ebe874175065ead3', '01859443459', NULL, NULL),
(6, 'Md.Rabiu Hasan', 'hasan@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '01624344039', NULL, NULL),
(7, 'Md.Rabiu Hasan', 'hasan@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '01859443458', NULL, NULL),
(8, 'fahim', 'fahim@gmail.com', '$2y$10$VdeclwMJa2BwsEax23cnt.bEdkPoZSv7.vFRZuXimTTn9GWtPlGwK', '123456', NULL, NULL),
(9, 'test', 'test@gmail.com', '$2y$10$jb6MPNLsAT4GktTrqfvuPuA27pU4J/C3mi6d8vutzdrx690OggC6i', '123456', NULL, NULL),
(10, 'annab', 'arnab@gmail.com', '$2y$10$ghBLAEg1DBGUs1YphOn36uCfO73HlkT8xRm3cvBwd2FL3LaDCjyae', '46546546', NULL, NULL),
(11, 'adnan', 'adnab@gmail.com', '$2y$10$aj.orhzlNisHVsMADsJUC.c4.9e3DCuN34Ytqiyya1gx/GHjUJU8m', '12345', NULL, NULL),
(12, 'farhan', 'farhan@gmail.com', '$2y$10$uU49IBmXdimSBQLu5x5qWOjilI8P4IhjzHO1BGeU25b7wIF9gTw6O', '01830850620', NULL, NULL),
(13, 'sabbir', 'sabbir@gmail.com', '$2y$10$vjygoPLDHeZP1pVuvXm7teITm9O/njdvMta5c0Djlvfc3VNbFoKfG', '798782121', NULL, NULL),
(14, 'rubel', 'rubel@gmail.com', '$2y$10$G8YGXLygbWMR5HPPbTRD9ebF/3Gh0W.2IjJTBy6hOwDwAGPcyoc1u', '01830850620', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menufecture`
--

CREATE TABLE `tbl_menufecture` (
  `menufecture_id` int(10) UNSIGNED NOT NULL,
  `menufecture_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `menufecture_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publication_status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_menufecture`
--

INSERT INTO `tbl_menufecture` (`menufecture_id`, `menufecture_name`, `menufecture_description`, `publication_status`, `created_at`, `updated_at`) VALUES
(1, 'Adidas', 'This is addidas brand.Linke Ronaldo', 1, NULL, NULL),
(2, 'Apple', 'This is apple page', 1, NULL, NULL),
(3, 'Samsung', 'This is samsung page', 1, NULL, NULL),
(4, 'Optical Glass', 'This is sunglass section', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `order_id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(11) NOT NULL,
  `shipping_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `order_total` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_status` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`order_id`, `customer_id`, `shipping_id`, `payment_id`, `order_total`, `order_status`, `created_at`, `updated_at`) VALUES
(3, 10, 29, 4, '180,000.00', 'pending', '2018-07-26 06:08:29', NULL),
(4, 10, 30, 5, '181,497.00', 'pending', '2018-07-26 06:15:43', NULL),
(5, 10, 30, 6, '181,497.00', 'pending', '2018-07-26 06:33:13', NULL),
(6, 10, 30, 7, '181,497.00', 'pending', '2018-07-26 06:33:26', NULL),
(7, 10, 30, 8, '0.00', 'pending', '2018-07-26 06:33:37', NULL),
(8, 10, 31, 9, '2,499.00', 'pending', '2018-07-26 06:37:23', NULL),
(9, 10, 31, 10, '0.00', 'pending', '2018-07-26 06:37:58', NULL),
(10, 10, 32, 11, '2,331.00', 'pending', '2018-07-26 06:38:56', NULL),
(11, 11, 33, 12, '5,497.00', 'pending', '2018-07-26 11:23:57', NULL),
(12, 12, 34, 13, '4,998.00', 'pending', '2018-07-26 13:09:56', NULL),
(13, 13, 35, 14, '5,554.00', 'pending', '2018-07-26 13:29:34', NULL),
(14, 12, 34, 15, '4,998.00', 'pending', '2018-07-26 14:09:09', NULL),
(15, 12, 36, 16, '9,442.00', 'pending', '2018-07-26 14:26:47', NULL),
(16, 12, 37, 17, '5,554.00', 'pending', '2018-07-26 14:34:57', NULL),
(17, 10, 38, 18, '5,554.00', 'pending', '2018-07-26 14:49:58', NULL),
(18, 10, 38, 19, '5,554.00', 'pending', '2018-07-26 14:50:29', NULL),
(19, 14, 39, 20, '627,210.00', 'pending', '2018-07-26 14:55:28', NULL),
(20, 14, 40, 21, '65,554.00', 'pending', '2018-07-26 15:01:23', NULL),
(21, 10, 41, 22, '904,491.00', 'pending', '2018-08-10 10:46:51', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_details`
--

CREATE TABLE `tbl_order_details` (
  `order_details_id` int(10) UNSIGNED NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_sales_quantity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_order_details`
--

INSERT INTO `tbl_order_details` (`order_details_id`, `order_id`, `product_id`, `product_name`, `product_price`, `product_sales_quantity`, `created_at`, `updated_at`) VALUES
(2, 4, 3, 'Samsung', '60000', '3', NULL, NULL),
(3, 4, 6, 'Brazil Blue Kit', '499', '3', NULL, NULL),
(4, 5, 3, 'Samsung', '60000', '3', NULL, NULL),
(5, 5, 6, 'Brazil Blue Kit', '499', '3', NULL, NULL),
(6, 6, 3, 'Samsung', '60000', '3', NULL, NULL),
(7, 8, 2, 'Samsung', '2000', '1', NULL, NULL),
(8, 10, 4, 'Shirt', '777', '3', NULL, NULL),
(9, 11, 6, 'Brazil Blue Kit', '499', '3', NULL, NULL),
(10, 12, 2, 'Samsung', '2000', '2', NULL, NULL),
(11, 12, 6, 'Brazil Blue Kit', '499', '2', NULL, NULL),
(12, 13, 4, 'Shirt', '777', '2', NULL, NULL),
(13, 14, 2, 'Samsung', '2000', '2', NULL, NULL),
(14, 15, 5, 'Shari', '2222', '2', NULL, NULL),
(15, 16, 2, 'Samsung', '2000', '2', NULL, NULL),
(16, 18, 4, 'Shirt', '777', '2', NULL, NULL),
(17, 19, 3, 'Samsung', '60000', '10', NULL, NULL),
(18, 20, 2, 'Samsung', '2000', '2', NULL, NULL),
(19, 20, 4, 'Shirt', '777', '2', NULL, NULL),
(20, 20, 3, 'Samsung', '60000', '1', NULL, NULL),
(21, 21, 6, 'Bat', '499', '9', NULL, NULL),
(22, 21, 2, 'apple', '450000', '2', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `payment_id` int(10) UNSIGNED NOT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`payment_id`, `payment_method`, `payment_status`, `created_at`, `updated_at`) VALUES
(4, 'handcash', 'pending', '2018-07-26 06:08:29', NULL),
(5, 'Debit', 'pending', '2018-07-26 06:15:42', NULL),
(6, 'Debit', 'pending', '2018-07-26 06:33:12', NULL),
(7, 'handcash', 'pending', '2018-07-26 06:33:26', NULL),
(8, 'handcash', 'pending', '2018-07-26 06:33:36', NULL),
(9, 'handcash', 'pending', '2018-07-26 06:37:23', NULL),
(10, 'handcash', 'pending', '2018-07-26 06:37:58', NULL),
(11, 'handcash', 'pending', '2018-07-26 06:38:56', NULL),
(12, 'handcash', 'pending', '2018-07-26 11:23:57', NULL),
(13, 'Debit', 'pending', '2018-07-26 13:09:56', NULL),
(14, 'handcash', 'pending', '2018-07-26 13:29:34', NULL),
(15, 'handcash', 'pending', '2018-07-26 14:09:09', NULL),
(16, 'handcash', 'pending', '2018-07-26 14:26:47', NULL),
(17, 'handcash', 'pending', '2018-07-26 14:34:57', NULL),
(18, 'handcash', 'pending', '2018-07-26 14:49:58', NULL),
(19, 'handcash', 'pending', '2018-07-26 14:50:29', NULL),
(20, 'handcash', 'pending', '2018-07-26 14:55:28', NULL),
(21, 'handcash', 'pending', '2018-07-26 15:01:23', NULL),
(22, 'handcash', 'pending', '2018-08-10 10:46:51', NULL),
(23, 'handcash', 'pending', '2018-08-11 20:17:16', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `product_id` int(10) UNSIGNED NOT NULL,
  `product_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `menufecture_id` int(11) NOT NULL,
  `product_short_description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_long_description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` double(8,2) NOT NULL,
  `product_image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publication_status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`product_id`, `product_name`, `category_id`, `menufecture_id`, `product_short_description`, `product_long_description`, `product_price`, `product_image`, `product_size`, `product_color`, `publication_status`, `created_at`, `updated_at`) VALUES
(2, 'apple', 10, 2, 'Samsung J7', 'This is the best phone', 450000.00, 'image/e1577c7964TOSHIBA.jpg', '1125 x 2436 pixels, 19.5:9 ratio (~458 ppi density)', 'white', 1, NULL, NULL),
(3, 'Samsung', 10, 1, 'ef gbhsdfsdfsdfs', 'hgfhddsdfsdfsdfsdf', 60000.00, 'image/4511f7c69asamsung.jpg', '1125 x 2436 pixels, 19.5:9 ratio (~458 ppi density)', 'Space Gray,', 1, NULL, NULL),
(4, 'Shirt', 5, 1, 'wa3t fger', 'sdfgsdgs', 777.00, 'image/c03ac87dc7bang.jpg', 'xl,m,l,s', 'Space Gray,', 1, NULL, NULL),
(5, 'child_dress', 5, 1, 'dsgvbfsd', 'dfgsdfgds', 2222.00, 'image/09e7c22553child.jpg', 'xl,m,l,s', 'white', 1, NULL, NULL),
(6, 'Bat', 9, 1, 'Brazil National kit', '<span style=\"font-size: 13.3333px;\">This is best kit in the world</span>', 499.00, 'image/d32af5a2efbat.jpg', 'xl,m,l,s', 'Blue,Yellow', 1, NULL, NULL),
(7, 'watch', 11, 3, 'fsdfsdfsdf', 'sdfsdfsdf', 10000.00, 'image/bd72892d68Branded-Watch-Transparent-Background.png', 'all', 'steel', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_shipping`
--

CREATE TABLE `tbl_shipping` (
  `shipping_id` int(10) UNSIGNED NOT NULL,
  `shipping_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_mobile_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_shipping`
--

INSERT INTO `tbl_shipping` (`shipping_id`, `shipping_email`, `shipping_first_name`, `shipping_last_name`, `shipping_address`, `shipping_mobile_number`, `shipping_city`, `created_at`, `updated_at`) VALUES
(14, 'faisal@gmail.com', 'faisal', 'ahmed', 'noyakhali', '01254687', 'cumilla', NULL, NULL),
(15, 'faisal@gmail.com', 'faisal', 'ahmed', 'noyakhali', '01254687', 'cumilla', NULL, NULL),
(16, 'faisal@gmail.com', 'faisal', 'ahmed', 'noyakhali', '01254687', 'cumilla', NULL, NULL),
(17, 'faisal@gmail.com', 'faisal', 'ahmed', 'noyakhali', '01254687', 'cumilla', NULL, NULL),
(18, 'fsfsd@gan', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdffs', NULL, NULL),
(19, 'fsfsd@gan', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdffs', NULL, NULL),
(20, 'fsfsd@gan', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdffs', NULL, NULL),
(21, 'jahid@gmail.com', 'jahid', 'hasan', 'cumilla', '01254687', 'cumilla', NULL, NULL),
(22, 'kahan@gmail.com', 'faisal', 'ahmed', 'noyakhali', '01254687', 'cumilla', NULL, NULL),
(23, 'faisal@gmail.com', 'faisal', 'ahmed', 'noyakhali', '01254687', 'cumilla', NULL, NULL),
(24, 'faisal@gmail.com', 'faisal', 'ahmed', 'noyakhali', '01254687', 'cumilla', NULL, NULL),
(25, 'faisal@gmail.com', 'faisal', 'ahmed', 'noyakhali', '01254687', 'cumilla', NULL, NULL),
(26, 'fdskj@gmai.com', 'dsfsdf', 'fsdf', 'sddsffsd', 'rwerwer', 'rwefdsfsd', NULL, NULL),
(27, 'fdsfdsf@gmail.con', 'sfsdfsd', 'sdfsdf', 'sdfsdfsdf', 'sdafsdf', 'sdfsdf', NULL, NULL),
(28, 'sfsd@gmail.com', 'sdfdsf', 'sdfsd', 'sdfsdf', 'sdfsd', 'sdfsdf', NULL, NULL),
(29, 'jahid@gmail.com', 'faisal', 'ahmed', 'noyakhali', '01254687', 'cumilla', NULL, NULL),
(30, 'subro@gmail.com', 'subroto', 'mohonto', 'dhaka', '01254687', 'cumilla', NULL, NULL),
(31, 'faisal@gmail.com', 'faisal', 'ahmed', 'noyakhali', '01254687', 'cumilla', NULL, NULL),
(32, 'kahan@gmail.com', 'faisal', 'ahmed', 'sdfsdf', '01254687', 'cumilla', NULL, NULL),
(33, 'mojid@gmail.com', 'mojid', 'mojid', 'noyakhali', '01254687', 'cumilla', NULL, NULL),
(34, 'mahin@gmailc.om', 'mahin', 'khan', 'borisal', '01620601859', 'sodor', NULL, NULL),
(35, 'masud@gmail.com', 'masud', 'alam', 'dhaka', '89711211', 'dhka', NULL, NULL),
(36, 'test@gmial.com', 'sfsdf', 'sfdsdf', 'dsfsdf', '342423', 'sdfsd', NULL, NULL),
(37, 'ffsdf@gmail', 'sfdsf', 'sfsdfs', 'sdfsdf', 'sdfsdf', 'fsdf', NULL, NULL),
(38, 'hanif@gmail.com', 'sdfsdf', 'sdfsdf', 'dsfdsf', 'dsfsdf', 'sdfsdf', NULL, NULL),
(39, 'mahmud@gmail.com', 'sdfsd', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', NULL, NULL),
(40, 'khsdfksdjh@gmail', 'kalid', 'sfsdf', 'sfsdf', 'fsdf', 'sdfsd', NULL, NULL),
(41, 'kahan@gmail.com', 'faisal', 'sdfsdf', 'sdfsdf', '01254687', 'cumilla', NULL, NULL),
(42, 'kahan@gmail.com', 'faisal', 'ahmed', 'noyakhali', '01254687', 'cumilla', NULL, NULL),
(43, 'faisal@gmail.com', 'faisal', 'ahmed', 'noyakhali', 'sdfsdf', 'cumilla', NULL, NULL),
(44, 'faisal@gmail.com', 'faisal', 'ahmed', 'noyakhali', '01254687', 'cumilla', NULL, NULL),
(45, 'faisal@gmail.com', 'faisal', 'sdfsdf', 'sdfsdf', '342423', 'cumilla', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slider`
--

CREATE TABLE `tbl_slider` (
  `slider_id` int(10) UNSIGNED NOT NULL,
  `slider_image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publication_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_slider`
--

INSERT INTO `tbl_slider` (`slider_id`, `slider_image`, `publication_status`, `created_at`, `updated_at`) VALUES
(4, 'slider/9usr5QLlsA8mv7tx92Yt.png', '1', NULL, NULL),
(5, 'slider/us7I7daES5EeexeJXrfb.png', '1', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `tbl_menufecture`
--
ALTER TABLE `tbl_menufecture`
  ADD PRIMARY KEY (`menufecture_id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  ADD PRIMARY KEY (`order_details_id`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `tbl_shipping`
--
ALTER TABLE `tbl_shipping`
  ADD PRIMARY KEY (`shipping_id`);

--
-- Indexes for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  ADD PRIMARY KEY (`slider_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `category_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `customer_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_menufecture`
--
ALTER TABLE `tbl_menufecture`
  MODIFY `menufecture_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `order_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  MODIFY `order_details_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `payment_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `product_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_shipping`
--
ALTER TABLE `tbl_shipping`
  MODIFY `shipping_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  MODIFY `slider_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
